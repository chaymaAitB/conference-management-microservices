export interface Keynote {
  id?: number;
  nom: string;
  prenom: string;
  email: string;
  fonction: string;
}
